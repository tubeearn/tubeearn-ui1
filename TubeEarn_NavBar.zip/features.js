const features = [
  { name: "Home", link: "#" },
  { name: "Shorts", link: "#shorts" },
  { name: "Videos", link: "#videos" },
  { name: "Live", link: "#live" },
  { name: "Education", link: "#education" },
  { name: "Singing", link: "#singing" },
  { name: "Dating", link: "#dating" },
  { name: "Shopping Mall", link: "#shopping" },
  { name: "Marketplace", link: "#marketplace" },
  { name: "Video Editor", link: "#editor" },
  { name: "Audio Editor", link: "#audioeditor" },
  { name: "Coming Features", link: "#coming" }
];

const navMenu = document.getElementById("nav-menu");

features.forEach(feature => {
  const li = document.createElement("li");
  const a = document.createElement("a");
  a.textContent = feature.name;
  a.href = feature.link;
  li.appendChild(a);
  navMenu.appendChild(li);
});
